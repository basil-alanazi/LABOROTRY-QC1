// Lets someone send themselves a test push right away from My Profile,
// without waiting for an actual shift's timing to line up.
import { createClient } from "@supabase/supabase-js";
import webpush from "web-push";

const vapidPublic = "BG1GixDqBtaS_l5ZCEtdp31H7NFkzHtN_h4ZErPbO5g3Yy5UlxV3psvqE3dUxJhj9zsdWdDsuluiL2tUJKcTbR0";

export default async function handler(req, res) {
  const username = req.query?.username || req.body?.username;
  if (!username) return res.status(400).json({ error: "Missing username" });

  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
  const vapidPrivate = process.env.VAPID_PRIVATE_KEY;
  if (!supabaseUrl || !supabaseKey) return res.status(500).json({ error: "Missing Supabase env vars" });
  if (!vapidPrivate) return res.status(500).json({ error: "Missing VAPID_PRIVATE_KEY env var" });

  webpush.setVapidDetails("mailto:admin@example.com", vapidPublic, vapidPrivate);
  const supabase = createClient(supabaseUrl, supabaseKey);

  const { data: subs } = await supabase.from("push_subscriptions").select("*").eq("username", username);
  if (!subs || subs.length === 0) return res.status(404).json({ error: "No subscription found — enable shift reminders in My Profile first." });

  let sent = 0;
  const failures = [];
  for (const s of subs) {
    try {
      await webpush.sendNotification(s.subscription, JSON.stringify({
        title: "🔔 Test notification",
        body: "If you can see this, your shift reminders are working perfectly! — Rabia Hospital Lab Family",
        tag: "test",
      }));
      sent++;
    } catch (err) {
      failures.push(err.message);
      if (err.statusCode === 404 || err.statusCode === 410) {
        await supabase.from("push_subscriptions").delete().eq("id", s.id);
      }
    }
  }

  res.status(200).json({ sent, failures });
}
